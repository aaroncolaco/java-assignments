package com.psl;

public class Client {

	
	public int findAge(String birthDate) throws InvalidDateFormatException {
		//Write a code here to calculate the age using the birthdate 
	}

	public static void main(String[] args) {
		// You can test your code by calling findAge() method from here
	}

}

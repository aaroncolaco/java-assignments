package com.psl;


public class Client {
	
	public static void main(String[] args) {
		//Call your methods from here  to test the code implemented
	}
}
package com.util;


// Override and implement the methods of Interface DataManager here 
public class DataManagerImpl implements DataManager {

}

package com.psl;

import com.psl.util.PhoneBookContacts;
import com.psl.util.PhoneBookContactsImpl;

public class Client {
	
	public static void main(String[] args){
		
		//test your code by calling methods of the PhoneBookContacts from here
		
		PhoneBookContacts contacts=new PhoneBookContactsImpl();
		
	}
}

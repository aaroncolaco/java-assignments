package com.psl;

public class Client {

	public String[] getTokens(String data) {
		//Write a code here to tokenize the words in the given String and return an array of words
		return null;
	}

	public String reverseAndAppend(String[] data) {
		//Write a code here to reverse and append the words in the passed array
		return null;
	}

	public static void main(String[] args) {
		//Check your code by calling methods from here
		Client client=new Client();
		String[] tokens=client.getTokens("Hello World");
		client.reverseAndAppend(tokens);		
		
	}

}

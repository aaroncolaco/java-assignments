package com.psl;

public class Client {
	
	public static void main(String[] args) {
		
		// Call all the functionalities from here to test your code.    
	}
}

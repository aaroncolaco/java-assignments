package com.util;

//Override and implement all the methods of DataManger Interface in this class
public class DataManagerImpl implements DataManager {
	
}

package com.util;

import java.sql.Connection;
import java.sql.SQLException;


//Override and implement all the methods of DBConnectionUtil Interface in this class 
public class DatabaseConnectionManager implements DBConnectionUtil {		
		
}

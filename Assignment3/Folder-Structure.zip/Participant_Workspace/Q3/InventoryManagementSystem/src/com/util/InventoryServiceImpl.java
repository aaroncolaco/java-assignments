package com.util;

import java.util.List;

import com.bean.Item;
import com.exception.NoDataFoundException;

// Override and implement all the methods of DBConnectionUtil Interface in this class
public class InventoryServiceImpl implements InventoryService {
		
}

package com.psl;

public class Client {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// Call all the functionalities from here to test your code.
	}
		
}

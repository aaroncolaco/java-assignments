package com.bean;

public enum Complexity {
	 Simple, Complex, Medium
}

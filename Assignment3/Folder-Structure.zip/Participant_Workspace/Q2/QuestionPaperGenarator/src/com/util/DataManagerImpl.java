package com.util;

// Override and implement all the methods of DataManager Interface here
public class DataManagerImpl implements DataManager {


}